import React from 'react'

function Form() {
  return (
    <>
    <div>
    <input type='text'>Name</input>
    </div>
    </>
  )
}

export default Form